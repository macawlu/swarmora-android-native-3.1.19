package com.telesync.app

import android.app.Activity
import android.net.Uri
import android.content.pm.ActivityInfo
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class NativePlayerController(private val activity: Activity) {
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var container: FrameLayout? = null

    fun isOpen(): Boolean = playerView != null

    fun play(rawUrl: String, title: String? = null, subtitleUrl: String? = null): Boolean {
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return false
        if (uri.scheme?.lowercase() !in setOf("http", "https")) return false

        activity.runOnUiThread {
            close()
            val exo = ExoPlayer.Builder(activity).build()
            val view = PlayerView(activity).apply {
                useController = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                isFocusable = true
                isFocusableInTouchMode = true
                player = exo
            }
            val root = FrameLayout(activity).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                addView(view, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                ))
            }
            val itemBuilder = MediaItem.Builder().setUri(uri)
            if (!title.isNullOrBlank()) itemBuilder.setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder().setTitle(title.take(300)).build()
            )
            if (!subtitleUrl.isNullOrBlank()) {
                val subUri = runCatching { Uri.parse(subtitleUrl) }.getOrNull()
                if (subUri != null && subUri.scheme?.lowercase() in setOf("http", "https")) {
                    val mime = when {
                        subtitleUrl.contains(".vtt", true) -> MimeTypes.TEXT_VTT
                        subtitleUrl.contains(".ssa", true) || subtitleUrl.contains(".ass", true) -> MimeTypes.TEXT_SSA
                        else -> MimeTypes.APPLICATION_SUBRIP
                    }
                    itemBuilder.setSubtitleConfigurations(
                        listOf(MediaItem.SubtitleConfiguration.Builder(subUri)
                            .setMimeType(mime).setSelectionFlags(1).build())
                    )
                }
            }
            exo.setMediaItem(itemBuilder.build())
            exo.prepare()
            exo.playWhenReady = true
            exo.play()
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            player = exo
            playerView = view
            container = root
            activity.addContentView(root, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
            TelesyncWebBridge.setImmersive(activity, true)
            view.requestFocus()
        }
        return true
    }

    fun close() {
        val oldRoot = container
        playerView?.player = null
        player?.release()
        player = null
        playerView = null
        container = null
        (oldRoot?.parent as? ViewGroup)?.removeView(oldRoot)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        TelesyncWebBridge.setImmersive(activity, false)
    }

    fun handleKey(keyCode: Int): Boolean {
        val exo = player ?: return false
        return when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (exo.isPlaying) exo.pause() else exo.play(); true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { exo.play(); true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { exo.pause(); true }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                exo.seekTo((exo.currentPosition + 10_000).coerceAtMost(exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE)); true
            }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); true
            }
            else -> false
        }
    }
}
