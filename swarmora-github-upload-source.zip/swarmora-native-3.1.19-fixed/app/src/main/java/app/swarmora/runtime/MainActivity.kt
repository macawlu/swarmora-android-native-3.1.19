package app.swarmora.runtime

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Swarmora Android Native Runtime 3.1.19
 *
 * - Fixes TelesyncNativeFile bridge (@JavascriptInterface) so downloads work.
 * - ExoPlayer is the default native player (window.SwarmoraAndroid.playNative).
 * - Torrent prepare path is untouched (SwarmoraRuntime.aar).
 * - Auth remains private via login.html / QR (device.html) on the existing site.
 */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var nativePlayer: NativePlayerController
    private val startUrl = "https://swarmora-alfa.vercel.app/?source=android-native-runtime"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        nativePlayer = NativePlayerController(this)

        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportZoom(false)
        s.userAgentString = s.userAgentString + " SwarmoraAndroid/3.1.19-NativeRuntime"

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.addJavascriptInterface(NativeBridge(this, nativePlayer), "SwarmoraAndroid")
        web.addJavascriptInterface(NativeFileSaveBridge(this), "TelesyncNativeFile")
        web.webChromeClient = WebChromeClient()

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                installNativeSaveFilePicker(view)
                view.postDelayed({ installNativeSaveFilePicker(view) }, 400)
                view.postDelayed({ installNativeSaveFilePicker(view) }, 1500)
                installNativePlayerHook(view)
            }

            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                return if (u.startsWith("https://swarmora-alfa.vercel.app/")) false else openExternal(u)
            }
        }

        web.setDownloadListener(DownloadListener { url, _, contentDisposition, _, _ ->
            val name = contentDisposition
                ?.substringAfter("filename=", "swarmora-download")
                ?.trim('"', '\'')
                ?: "swarmora-download"
            startNativeDownload(url, name)
        })

        if (state == null) web.loadUrl(startUrl) else web.restoreState(state)
        requestNotificationPermission()
    }

    private fun installNativeSaveFilePicker(view: WebView) {
        val script = """
            (function(){
              if (!window.TelesyncNativeFile) return;
              if (typeof window.TelesyncNativeFile.begin !== 'function') return;

              const nativePicker = async function(options) {
                const opts = options || {};
                const suggested = opts.suggestedName || "swarmora-download";
                let mime = "application/octet-stream";
                try {
                  const accept = opts.types && opts.types[0] && opts.types[0].accept;
                  if (accept) {
                    const keys = Object.keys(accept);
                    if (keys.length) mime = keys[0];
                  }
                } catch (_) {}

                const started = window.TelesyncNativeFile.begin(String(suggested), String(mime));
                if (String(started).indexOf("ok") !== 0) {
                  throw new Error(String(started));
                }

                let closed = false;

                return {
                  kind: "file",
                  name: String(suggested),
                  async getFile() {
                    return new File([], String(suggested), {type: String(mime)});
                  },
                  async createWritable() {
                    return {
                      async write(data) {
                        let blob;
                        if (data instanceof Blob) blob = data;
                        else if (data instanceof ArrayBuffer) blob = new Blob([data]);
                        else if (ArrayBuffer.isView(data)) {
                          blob = new Blob([data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength)]);
                        } else if (typeof data === "string") {
                          blob = new Blob([data]);
                        } else if (data && data.data) {
                          return this.write(data.data);
                        } else {
                          blob = new Blob([data]);
                        }
                        const buf = await blob.arrayBuffer();
                        const bytes = new Uint8Array(buf);
                        const part = 48 * 1024;
                        for (let i = 0; i < bytes.length; i += part) {
                          const sub = bytes.subarray(i, Math.min(i + part, bytes.length));
                          let bin = "";
                          for (let j = 0; j < sub.length; j++) bin += String.fromCharCode(sub[j]);
                          const ok = window.TelesyncNativeFile.writeBase64(btoa(bin));
                          if (String(ok).indexOf("ok") !== 0) throw new Error(String(ok));
                        }
                      },
                      async close() {
                        if (!closed) {
                          closed = true;
                          const r = window.TelesyncNativeFile.finish();
                          if (String(r).indexOf("error:") === 0) throw new Error(String(r));
                        }
                      },
                      async abort() {
                        if (!closed) {
                          closed = true;
                          window.TelesyncNativeFile.cancel();
                        }
                      }
                    };
                  }
                };
              };

              try {
                if (window.showSaveFilePicker) {
                  window.__swarmoraOriginalShowSaveFilePicker = window.showSaveFilePicker;
                }
                window.showSaveFilePicker = nativePicker;
              } catch (_) {}

              window.__telesyncNativePickerInstalled = true;
              window.__telesyncNativePickerVersion = "3.1.19";
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun installNativePlayerHook(view: WebView) {
        val script = """
            (function(){
              if (window.__swarmoraNativePlayerHooked) return;
              window.__swarmoraNativePlayerHooked = true;
              window.swarmoraPlayNative = function(url, title, subtitle) {
                try {
                  if (window.SwarmoraAndroid && typeof window.SwarmoraAndroid.playNative === 'function') {
                    return window.SwarmoraAndroid.playNative(
                      String(url || ''),
                      String(title || ''),
                      String(subtitle || '')
                    );
                  }
                } catch (e) {}
                return false;
              };
            })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun startNativeDownload(url: String, name: String) {
        val cookie = CookieManager.getInstance().getCookie(url)
        val i = Intent(this, NativeDownloadService::class.java).apply {
            action = NativeDownloadService.ACTION_START
            putExtra("url", url)
            putExtra("name", name)
            putExtra("cookie", cookie)
        }
        ContextCompat.startForegroundService(this, i)
        Toast.makeText(this, "Download nativo iniciado", Toast.LENGTH_SHORT).show()
    }

    private fun openExternal(url: String): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Throwable) {
            true
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (nativePlayer.isOpen()) {
            nativePlayer.close()
            web.requestFocus()
            return
        }
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (nativePlayer.isOpen()) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                nativePlayer.close()
                web.requestFocus()
                return true
            }
            if (nativePlayer.handleKey(keyCode)) return true
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER
        ) {
            if (event != null) web.dispatchKeyEvent(event)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onSaveInstanceState(out: Bundle) {
        web.saveState(out)
        super.onSaveInstanceState(out)
    }

    override fun onDestroy() {
        nativePlayer.close()
        runCatching {
            web.removeJavascriptInterface("SwarmoraAndroid")
            web.removeJavascriptInterface("TelesyncNativeFile")
            web.destroy()
        }
        super.onDestroy()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        }
    }

    class NativeBridge(
        private val activity: MainActivity,
        private val nativePlayer: NativePlayerController
    ) {
        @JavascriptInterface
        fun getRuntimeName() = "Swarmora Android Native Runtime"

        @JavascriptInterface
        fun getRuntimeVersion() = "3.1.19"

        @JavascriptInterface
        fun isAndroidRuntime() = true

        @JavascriptInterface
        fun hasNativePlayer() = true

        @JavascriptInterface
        fun playNative(url: String?, title: String?, subtitle: String?): Boolean {
            val u = url?.trim().orEmpty()
            if (u.isEmpty()) return false
            return nativePlayer.play(u, title, subtitle)
        }

        @JavascriptInterface
        fun closeNativePlayer() {
            nativePlayer.close()
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Throwable) {
            }
        }
    }
}
