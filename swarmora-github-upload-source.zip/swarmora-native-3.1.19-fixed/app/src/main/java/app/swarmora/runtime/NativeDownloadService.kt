package app.swarmora.runtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class NativeDownloadService : Service() {
    companion object { const val ACTION_START = "app.swarmora.runtime.DOWNLOAD" }
    private val channelId = "swarmora_downloads"

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "Swarmora Downloads", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) { stopSelf(startId); return START_NOT_STICKY }
        val url = intent.getStringExtra("url") ?: return stopWith(startId)
        val name = sanitize(intent.getStringExtra("name") ?: "swarmora-download")
        val cookie = intent.getStringExtra("cookie")
        startForeground(42, notification("Baixando $name", 0))
        Thread {
            try {
                val out = File(getExternalFilesDir(null), name)
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000; readTimeout = 60_000
                    if (!cookie.isNullOrBlank()) setRequestProperty("Cookie", cookie)
                }
                conn.connect()
                val total = conn.contentLengthLong
                var done = 0L
                conn.inputStream.use { input -> out.outputStream().use { output ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        output.write(buf, 0, n); done += n
                        if (total > 0) update(notification("Baixando $name", (done * 100 / total).toInt()))
                    }
                }}
                update(notification("Download concluído: $name", 100, true))
                stopSelf(startId)
            } catch (_: Throwable) {
                update(notification("Falha no download: $name", 0, true)); stopSelf(startId)
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun stopWith(id: Int): Int { stopSelf(id); return START_NOT_STICKY }
    private fun sanitize(s: String) = s.replace(Regex("[\\/:*?\"<>|]"), "_").take(180)
    private fun update(n: android.app.Notification) = getSystemService(NotificationManager::class.java).notify(42, n)
    private fun notification(text: String, progress: Int, done: Boolean = false): android.app.Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, channelId).setSmallIcon(R.drawable.ic_swarmora).setContentTitle("Swarmora").setContentText(text).setContentIntent(pi).setOngoing(!done).setOnlyAlertOnce(true)
        return if (!done) b.setProgress(100, progress, false).build() else b.setProgress(0, 0, false).build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
