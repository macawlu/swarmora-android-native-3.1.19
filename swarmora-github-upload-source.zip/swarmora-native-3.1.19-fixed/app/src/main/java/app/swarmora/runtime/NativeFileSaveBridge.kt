package app.swarmora.runtime

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.File
import java.io.OutputStream

/**
 * Native bridge exposed to the WebView as window.TelesyncNativeFile.
 *
 * FIX 3.1.19: all public methods are annotated with @JavascriptInterface.
 * Without this annotation Android does not expose the methods to JavaScript,
 * which produced the runtime error:
 *   "window.TelesyncNativeFile.begin is not a function"
 */
class NativeFileSaveBridge(private val context: Context) {
    private var uri: Uri? = null
    private var output: OutputStream? = null
    private var legacyFile: File? = null
    private var displayName: String = "swarmora-download"

    @JavascriptInterface
    @Synchronized
    fun begin(name: String?, mime: String?): String {
        closeQuietly()
        displayName = sanitize(name ?: "swarmora-download")
        val type = mime?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                    put(MediaStore.Downloads.MIME_TYPE, type)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Swarmora")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val created = context.contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
                ) ?: throw IllegalStateException("Não foi possível criar o arquivo em Download/Swarmora")
                uri = created
                output = context.contentResolver.openOutputStream(created)
                    ?: throw IllegalStateException("Não foi possível abrir o arquivo")
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "Swarmora"
                )
                if (!dir.exists()) dir.mkdirs()
                legacyFile = File(dir, displayName)
                output = legacyFile!!.outputStream()
            }
            "ok"
        } catch (t: Throwable) {
            closeQuietly()
            "error:" + (t.message ?: t.javaClass.simpleName)
        }
    }

    @JavascriptInterface
    @Synchronized
    fun writeBase64(chunk: String?): String {
        return try {
            if (chunk.isNullOrEmpty() || output == null) return "error:not-open"
            output!!.write(Base64.decode(chunk, Base64.DEFAULT))
            output!!.flush()
            "ok"
        } catch (t: Throwable) {
            "error:" + (t.message ?: t.javaClass.simpleName)
        }
    }

    @JavascriptInterface
    @Synchronized
    fun finish(): String {
        return try {
            closeQuietly()
            uri?.let {
                if (Build.VERSION.SDK_INT >= 29) {
                    context.contentResolver.update(
                        it,
                        ContentValues().apply {
                            put(MediaStore.Downloads.IS_PENDING, 0)
                        },
                        null,
                        null
                    )
                }
            }
            val result = uri?.toString() ?: legacyFile?.absolutePath ?: ""
            uri = null
            legacyFile = null
            result
        } catch (t: Throwable) {
            "error:" + (t.message ?: t.javaClass.simpleName)
        }
    }

    @JavascriptInterface
    @Synchronized
    fun cancel(): String {
        closeQuietly()
        uri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
        legacyFile?.let { runCatching { it.delete() } }
        uri = null
        legacyFile = null
        return "ok"
    }

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun getVersion(): String = "3.1.19"

    private fun closeQuietly() {
        runCatching { output?.close() }
        output = null
    }

    private fun sanitize(value: String): String {
        val cleaned = value.replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), "_").trim()
        return if (cleaned.isBlank()) "swarmora-download" else cleaned.take(180)
    }
}
