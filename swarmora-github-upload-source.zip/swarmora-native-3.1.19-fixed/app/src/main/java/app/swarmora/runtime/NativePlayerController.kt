package app.swarmora.runtime

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * Default media player for Swarmora (ExoPlayer / Media3).
 * Opened fullscreen on top of the activity; closed with Back.
 */
class NativePlayerController(private val activity: Activity) {
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var container: FrameLayout? = null

    fun isOpen(): Boolean = playerView != null

    fun play(rawUrl: String, title: String? = null, subtitleUrl: String? = null): Boolean {
        val uri = runCatching { Uri.parse(rawUrl) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase()
        if (scheme !in setOf("http", "https")) return false

        activity.runOnUiThread {
            closeInternal()
            val exo = ExoPlayer.Builder(activity).build()
            val view = PlayerView(activity).apply {
                useController = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                isFocusable = true
                isFocusableInTouchMode = true
                player = exo
            }
            val root = FrameLayout(activity).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }

            val itemBuilder = MediaItem.Builder().setUri(uri)
            if (!title.isNullOrBlank()) {
                itemBuilder.setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(title.take(300))
                        .build()
                )
            }
            if (!subtitleUrl.isNullOrBlank()) {
                val subUri = runCatching { Uri.parse(subtitleUrl) }.getOrNull()
                if (subUri != null && subUri.scheme?.lowercase() in setOf("http", "https")) {
                    val mime = when {
                        subtitleUrl.contains(".vtt", true) -> MimeTypes.TEXT_VTT
                        subtitleUrl.contains(".ssa", true) || subtitleUrl.contains(".ass", true) -> MimeTypes.TEXT_SSA
                        else -> MimeTypes.APPLICATION_SUBRIP
                    }
                    itemBuilder.setSubtitleConfigurations(
                        listOf(
                            MediaItem.SubtitleConfiguration.Builder(subUri)
                                .setMimeType(mime)
                                .setSelectionFlags(1)
                                .build()
                        )
                    )
                }
            }

            exo.setMediaItem(itemBuilder.build())
            exo.prepare()
            exo.playWhenReady = true
            exo.play()

            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            player = exo
            playerView = view
            container = root
            activity.addContentView(
                root,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            setImmersive(true)
            view.requestFocus()
        }
        return true
    }

    fun close() {
        activity.runOnUiThread { closeInternal() }
    }

    private fun closeInternal() {
        val oldRoot = container
        playerView?.player = null
        player?.release()
        player = null
        playerView = null
        container = null
        (oldRoot?.parent as? ViewGroup)?.removeView(oldRoot)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        setImmersive(false)
    }

    fun handleKey(keyCode: Int): Boolean {
        val exo = player ?: return false
        return when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER -> {
                if (exo.isPlaying) exo.pause() else exo.play()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                exo.play(); true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                exo.pause(); true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                val target = (exo.currentPosition + 10_000).coerceAtMost(
                    exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                )
                exo.seekTo(target)
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0))
                true
            }
            else -> false
        }
    }

    private fun setImmersive(enabled: Boolean) {
        val decor = activity.window.decorView
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val controller = activity.window.insetsController
            if (enabled) {
                controller?.hide(android.view.WindowInsets.Type.systemBars())
                controller?.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                controller?.show(android.view.WindowInsets.Type.systemBars())
            }
        } else {
            @Suppress("DEPRECATION")
            decor.systemUiVisibility = if (enabled) {
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            } else {
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
    }
}
