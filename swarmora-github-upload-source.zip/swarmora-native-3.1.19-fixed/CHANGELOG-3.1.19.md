# 3.1.19

## Bugfix
- **Download**: added `@JavascriptInterface` to NativeFileSaveBridge methods (`begin`, `writeBase64`, `finish`, `cancel`, `isAvailable`, `getVersion`). This fixes `window.TelesyncNativeFile.begin is not a function`.

## Feature
- **ExoPlayer** as default native player (`NativePlayerController` + `SwarmoraAndroid.playNative`).

## Unchanged
- Torrent prepare / metadata path (SwarmoraRuntime.aar) — no speed impact.
- Auth (login + QR) on swarmora-alfa.vercel.app.
- NativeDownloadService foreground downloads.
