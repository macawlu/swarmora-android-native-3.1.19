# Swarmora Android Native Runtime 3.1.19 (fixed)

## Correções nesta versão

1. **Download** — `NativeFileSaveBridge` agora expõe `begin` / `writeBase64` / `finish` / `cancel` com `@JavascriptInterface`.  
   Isso corrige o erro:
   ```text
   Não foi possível iniciar o download: window.TelesyncNativeFile.begin is not a function
   ```

2. **ExoPlayer como player padrão** — `NativePlayerController` (Media3/ExoPlayer) é o player nativo.  
   A página pode chamar:
   ```js
   window.SwarmoraAndroid.playNative(url, title, subtitle)
   // ou
   window.swarmoraPlayNative(url, title, subtitle)
   ```

3. **Prepare / torrent** — o caminho de metadados e o motor (`SwarmoraRuntime.aar`) **não foram alterados**. A velocidade de prepare permanece a mesma.

4. **Acesso privado** — login e QR continuam no site:
   - App: `https://swarmora-alfa.vercel.app/?source=android-native-runtime`
   - Login: `https://swarmora-alfa.vercel.app/login.html`
   - QR / device: `https://swarmora-alfa.vercel.app/device.html`

## Sobre “zero WebView”

O catálogo, login, QR e a UI de conteúdo vivem no frontend hospedado em Vercel.  
Este APK usa WebView **somente** para essa UI autenticada.  
**Player e download são 100% nativos** (ExoPlayer + MediaStore / NativeDownloadService).

Uma reescrita completa da UI em Views/Compose nativo exigiria reimplementar todo o produto (catálogo, auth, IPTV, console, etc.) e não está neste pacote — o código-fonte do frontend web não inclui a lógica de produto completa para um app nativo standalone.

## Build

- JDK 17  
- Android SDK (compileSdk 35)  
- Gradle 8.x  

```bash
cd swarmora-native-3.1.19-fixed
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

O `SwarmoraRuntime.aar` já está em `app/libs/`.

## Arquivos principais

| Arquivo | Função |
|---------|--------|
| `NativeFileSaveBridge.kt` | Ponte JS → MediaStore (download) — **corrigida** |
| `NativePlayerController.kt` | ExoPlayer fullscreen (player padrão) |
| `MainActivity.kt` | WebView + bridges + player |
| `NativeDownloadService.kt` | Download em foreground service |
| `app/libs/SwarmoraRuntime.aar` | Motor torrent / stream local |

## Version

- versionName: `3.1.19`  
- versionCode: `3119`  
- applicationId: `app.swarmora.runtime`
